_base_ = ['./depthfusion-light.py']

model = dict(
    img_view_transformer=dict(
        depth_loss_type='soft_ce',
        loss_depth_weight=0.1,
        loss_depth_edge_weight=0.0,
        depth_edge_alpha=1.0,
        edge_kernel_size=7))

work_dir = './work_dirs/depthfusion-light-ealss-dfl-depthsup'
