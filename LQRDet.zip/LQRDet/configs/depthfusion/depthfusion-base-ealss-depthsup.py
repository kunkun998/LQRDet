_base_ = ['./depthfusion-base.py']

model = dict(
    img_view_transformer=dict(
        loss_depth_weight=1.0,
        loss_depth_edge_weight=0.5,
        edge_kernel_size=7))

work_dir = './work_dirs/depthfusion-base-ealss-depthsup'
